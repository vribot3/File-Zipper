# File-Zipper
Huffman coding implementation
